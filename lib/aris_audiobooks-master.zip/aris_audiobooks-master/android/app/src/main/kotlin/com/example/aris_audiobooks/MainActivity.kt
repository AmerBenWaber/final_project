package com.example.aris_audiobooks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
